export type Role = {
  id: number;
  name: string;
  isActive: boolean;
};