export interface DeleteSectionProps {
  assessmentId: string;
  section: number;
}

export interface DeleteSectionResponse {
  status: string;
  message: string;
}
