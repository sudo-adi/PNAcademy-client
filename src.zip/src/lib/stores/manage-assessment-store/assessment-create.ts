"use client";
import { Option, Question } from '@/lib/types/assessmentTypes';
import { create } from 'zustand';

interface State {
  assessmentId: string;
  assessmentName: string;
  assessmentDescription: string;
  assessmentDuration: number;
  startsAt: string;
  endsAt: string;
  selectedGroups: string[];
  sectionContent: Question[] | null;
  assessmentContent: (Question[] | null)[];
  currentQuestionContent: string;
  currentQuestionId: string;
  currentQuestionMarks: number;
  currentOptionId: string;
  currentSectionIndex: number;
  currentQuestionIndex: number;
  currentOptions: Option[];
  totalSections: number;
  totalQuestions: string[];
  currentOptionIsCorrect: boolean;
  currentOptionContent: string;
  currentOption: Option;
}

interface Actions {
  setAssessmentId: (id: string) => void;
  setAssessmentName: (name: string) => void;
  setAssessmentDescription: (description: string) => void;
  setAssessmentDuration: (duration: number) => void;
  setStartsAt: (startsAt: string) => void;
  setEndsAt: (endsAt: string) => void;
  setSelectedGroups: (groups: string[]) => void;
  setSectionContent: (content: Question[] | null) => void;
  setAssessmentContent: (content: (Question[] | null)[]) => void;
  setTotalSections: (totalSections: number) => void;
  setCurrentSectionIndex: (section: number) => void;
  setTotalQuestions: (questions: string[]) => void;
  setCurrentQuestionId: (id: string) => void;
  setCurrentQuestionIndex: (question: number) => void;
  setCurrentQuestionMarks: (marks: number) => void;
  setCurrentOptions: (options: Option[]) => void;
  setCurrentQuestionContent: (content: string) => void;
  setCurrentOptionId: (id: string) => void;
  setCurrentOptionIsCorrect: (isCorrect: boolean) => void;
  setCurrentOptionContent: (content: string) => void;
  setOption: (option: Option) => void;
}

const useCreateAssessmentStore = create<State & Actions>((set) => ({
  // Initial State
  assessmentId: '',
  assessmentName: '',
  assessmentDescription: '',
  assessmentDuration: 0,
  startsAt: '',
  endsAt: '',
  selectedGroups: [],
  assessmentContent: [],
  sectionContent: [],
  currentQuestionContent: '',
  currentQuestionId: '',
  currentQuestionMarks: 0,
  currentOptionId: '',
  totalSections: 0,
  totalQuestions: [],
  currentSectionIndex: 0,
  currentQuestionIndex: 0,
  currentOptions: [],
  currentOption: {} as Option,
  currentOptionIsCorrect: false,
  currentOptionContent: "",

  // Actions
  setAssessmentId: (id) => set({ assessmentId: id }),
  setAssessmentName: (name) => set({ assessmentName: name }),
  setAssessmentDescription: (description) => set({ assessmentDescription: description }),
  setAssessmentDuration: (duration) => set({ assessmentDuration: duration }),
  setStartsAt: (startsAt) => set({ startsAt }),
  setEndsAt: (endsAt) => set({ endsAt }),
  setSectionContent: (content) => set({ sectionContent: content }),
  setSelectedGroups: (groups) => set({ selectedGroups: groups }),
  setAssessmentContent: (content) => set({ assessmentContent: content }),
  setTotalSections: (totalSections) => set({ totalSections }),
  setTotalQuestions: (questions) => set({ totalQuestions: questions }),
  setCurrentSectionIndex: (section) => set({ currentSectionIndex: section }),
  setCurrentQuestionIndex: (question) => set({ currentQuestionIndex: question }),
  setCurrentQuestionMarks: (marks) => set({ currentQuestionMarks: marks }),
  setCurrentOptions: (options) => set({ currentOptions: options }),
  setCurrentQuestionContent: (content) => set({ currentQuestionContent: content }),
  setCurrentQuestionId: (id) => set({ currentQuestionId: id }),
  setCurrentOptionId: (id) => set({ currentOptionId: id }),
  setCurrentOptionIsCorrect: (isCorrect) => set({ currentOptionIsCorrect: isCorrect }),
  setCurrentOptionContent: (content) => set({ currentOptionContent: content }),
  setOption: (option) => set({ currentOption: option }),
}));

export default useCreateAssessmentStore;
