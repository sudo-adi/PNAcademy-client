const validateAssessment = (assessmentId: string) => {
  
}