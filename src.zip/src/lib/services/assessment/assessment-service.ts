import { AxiosError } from 'axios';
import axiosInstance from '../../api/axiosInstance';
import { ApiError } from '../../api/apiError';


interface CreateAssessmentProps {
  name: string;
  description?: string;
  is_active: boolean;
  start_at: string;
  end_at: string;
  duration: number;
  created_by: string;
}

// Function to create an assessment
export const createAssessment = async (data: CreateAssessmentProps): Promise<void> => {
  try {
    const response = await axiosInstance.post('/v1/assessment/create', data);
    if (response.status === 200 || 201) {
      console.info('Assessment created successfully', response.data);
      return response.data;

    }
  } catch (error) {
    if (error instanceof AxiosError) {
      const { status, data } = error.response || {};
      switch (status) {
        case 400:
          throw new ApiError(status, 'Bad Request: Invalid data provided', data);
        case 500:
          throw new ApiError(status, 'Internal Server Error', data);
        default:
          throw new ApiError(status!, 'An unexpected error occurred', data);
      }
    } else {
      throw new ApiError(500, 'An unexpected error occurred', error);
    }
  }
};


interface GetAssessmentProps {
  id: string;
}

// Function to view an assessment
export const getAssessment = async ({ id }: GetAssessmentProps): Promise<any> => {
  try {
    const response = await axiosInstance.get('/v1/assessment/view', {
      params: { id },
    });

    if (response.status === 200 || 201) {
      console.info('Assessment fetched successfully', response.data);
      return response.data;
    }
  } catch (error) {
    if (error instanceof AxiosError) {
      const { status, data } = error.response || {};
      switch (status) {
        case 400:
          throw new ApiError(status, 'Bad Request: Invalid data provided', data);
        case 404:
          throw new ApiError(status, 'Not Found: Assessment not found', data);
        case 500:
          throw new ApiError(status, 'Internal Server Error', data);
        default:
          throw new ApiError(status!, 'An unexpected error occurred', data);
      }
    } else {
      throw new ApiError(500, 'An unexpected error occurred', error);
    }
  }
};


interface UpdateAssessmentProps {
  id: string;
  name: string;
  description?: string;
  is_active: boolean;
  start_at: string;
  end_at: string;
  duration: number;
}

// Function to update an assessment
export const updateAssessment = async (data: UpdateAssessmentProps): Promise<void> => {
  try {
    const response = await axiosInstance.patch('/v1/assessment/update', data);

    if (response.status === 200 || 201) {
      console.info('Assessment updated successfully', response.data);
      return response.data;
    }
  } catch (error) {
    if (error instanceof AxiosError) {
      const { status, data } = error.response || {};
      switch (status) {
        case 400:
          throw new ApiError(status, 'Bad Request: Invalid data provided', data);
        case 404:
          throw new ApiError(status, 'Not Found: Assessment not found', data);
        case 500:
          throw new ApiError(status, 'Internal Server Error', data);
        default:
          throw new ApiError(status!, 'An unexpected error occurred', data);
      }
    } else {
      throw new ApiError(500, 'An unexpected error occurred', error);
    }
  }
};


interface DeleteAssessmentProps {
  id: string;
}

// Function to delete an assessment
export const deleteAssessment = async ({ id }: DeleteAssessmentProps): Promise<void> => {
  try {
    const response = await axiosInstance.delete('/v1/assessment/delete', {
      data: { id },
    });

    if (response.status === 200 || 201) {
      console.info('Assessment deleted successfully', response.data);
      return;
    }
  } catch (error) {
    if (error instanceof AxiosError) {
      const { status, data } = error.response || {};
      switch (status) {
        case 400:
          throw new ApiError(status, 'Bad Request: Invalid data provided', data);
        case 404:
          throw new ApiError(status, 'Not Found: Assessment not found', data);
        case 500:
          throw new ApiError(status, 'Internal Server Error', data);
        default:
          throw new ApiError(status!, 'An unexpected error occurred', data);
      }
    } else {
      throw new ApiError(500, 'An unexpected error occurred', error);
    }
  }
};

// Function to Add Group to Assessment
interface AddGroupToAssessmentProps {
  assessmentId: string;
  groupId: string;
}

export const addGroupToAssessment = async (data: AddGroupToAssessmentProps): Promise<void> => {
  try {
    const response = await axiosInstance.post('/v1/assessment/add-group', data);

    if (response.status === 200 || 201) {
      console.info('Group added to assessment successfully', response.data);
      return response.data;
    }
  } catch (error) {
    if (error instanceof AxiosError) {
      const { status, data } = error.response || {};
      switch (status) {
        case 400:
          throw new ApiError(status, 'Bad Request: Invalid data provided', data);
        case 404:
          throw new ApiError(status, 'Not Found: Assessment or Group not found', data);
        case 500:
          throw new ApiError(status, 'Internal Server Error', data);
        default:
          throw new ApiError(status!, 'An unexpected error occurred', data);
      }
    } else {
      throw new ApiError(500, 'An unexpected error occurred', error);
    }
  }
};


interface GetAssignedAssessmentsProps {
  page: number;
  pageSize: number;
  sortBy: string;
  order: 'ASC' | 'DESC';
}

// Function to get assigned assessments
export const getAssignedAssessments = async ({
  page,
  pageSize,
  sortBy,
  order,
}: GetAssignedAssessmentsProps): Promise<void> => {
  try {
    const response = await axiosInstance.get(
      `/v1/assessment/assigned?page=${page}&pageSize=${pageSize}&sortBy=${sortBy}&order=${order}`
    );

    if (response.status === 200 || 201) {
      console.info('Assigned assessments retrieved successfully', response.data);
      return response.data;
    }
  } catch (error) {
    if (error instanceof AxiosError) {
      const { status, data } = error.response || {};
      switch (status) {
        case 400:
          throw new ApiError(status, 'Bad Request: Invalid parameters', data);
        case 401:
          throw new ApiError(status, 'Unauthorized: JWT token is missing or invalid', data);
        case 500:
          throw new ApiError(status, 'Internal Server Error', data);
        default:
          throw new ApiError(status!, 'An unexpected error occurred', data);
      }
    } else {
      throw new ApiError(500, 'An unexpected error occurred', error);
    }
  }
};

// Function to Remove Group from Assessment
interface RemoveGroupFromAssessmentProps {
  assessmentId: string;
  groupId: string;
}

export const removeGroupFromAssessment = async (data: RemoveGroupFromAssessmentProps): Promise<void> => {
  try {
    const response = await axiosInstance.delete('/v1/assessment/remove-group', {
      data,
    });

    if (response.status === 200 || 201) {
      console.info('Group removed from assessment successfully', response.data);
      return;
    }
  } catch (error) {
    if (error instanceof AxiosError) {
      const { status, data } = error.response || {};
      switch (status) {
        case 400:
          throw new ApiError(status, 'Bad Request: Invalid data provided', data);
        case 404:
          throw new ApiError(status, 'Not Found: Assessment or Group not found', data);
        case 500:
          throw new ApiError(status, 'Internal Server Error', data);
        default:
          throw new ApiError(status!, 'An unexpected error occurred', data);
      }
    } else {
      throw new ApiError(500, 'An unexpected error occurred', error);
    }
  }
};