import { ApiError } from '@/lib/api/apiError';
import axiosInstance from '@/lib/api/axiosInstance';
import { AxiosError } from 'axios';

interface CreateTagProps {
  name: string;
}

export const createTag = async (data: CreateTagProps): Promise<void> => {
  try {
    const response = await axiosInstance.post('/v1/assessment/tag', data);

    if (response.status === 200 || 201) {
      console.info('Tag created successfully', response.data);
      return response.data;
    }
  } catch (error) {
    if (error instanceof AxiosError) {
      const { status, data } = error.response || {};
      switch (status) {
        case 400:
          throw new ApiError(status, 'Bad Request: Invalid data provided', data);
        case 500:
          throw new ApiError(status, 'Internal Server Error', data);
        default:
          throw new ApiError(status!, 'An unexpected error occurred', data);
      }
    } else {
      throw new ApiError(500, 'An unexpected error occurred', error);
    }
  }
};

interface GetTagProps {
  id: string;
}

export const getTag = async ({ id }: GetTagProps): Promise<void> => {
  try {
    const response = await axiosInstance.get(`/v1/assessment/tag?id=${id}`);

    if (response.status === 200 || 201) {
      console.info('Tag retrieved successfully', response.data);
      return response.data;
    }
  } catch (error) {
    if (error instanceof AxiosError) {
      const { status, data } = error.response || {};
      switch (status) {
        case 400:
          throw new ApiError(status, 'Bad Request: Invalid data provided', data);
        case 404:
          throw new ApiError(status, 'Not Found: Tag not found', data);
        case 500:
          throw new ApiError(status, 'Internal Server Error', data);
        default:
          throw new ApiError(status!, 'An unexpected error occurred', data);
      }
    } else {
      throw new ApiError(500, 'An unexpected error occurred', error);
    }
  }
};


interface UpdateTagProps {
  id: string;
  name: string;
}

export const updateTag = async (data: UpdateTagProps): Promise<void> => {
  try {
    const response = await axiosInstance.patch('/v1/assessment/tag', data);

    if (response.status === 200 || 201) {
      console.info('Tag updated successfully', response.data);
      return response.data;
    }
  } catch (error) {
    if (error instanceof AxiosError) {
      const { status, data } = error.response || {};
      switch (status) {
        case 400:
          throw new ApiError(status, 'Bad Request: Invalid data provided', data);
        case 404:
          throw new ApiError(status, 'Not Found: Tag not found', data);
        case 500:
          throw new ApiError(status, 'Internal Server Error', data);
        default:
          throw new ApiError(status!, 'An unexpected error occurred', data);
      }
    } else {
      throw new ApiError(500, 'An unexpected error occurred', error);
    }
  }
};


interface DeleteTagProps {
  id: string;
}

export const deleteTag = async ({ id }: DeleteTagProps): Promise<void> => {
  try {
    const response = await axiosInstance.delete('/v1/assessment/tag', {
      data: { id },
    });

    if (response.status === 200 || 201) {
      console.info('Tag deleted successfully', response.data);
      return;
    }
  } catch (error) {
    if (error instanceof AxiosError) {
      const { status, data } = error.response || {};
      switch (status) {
        case 400:
          throw new ApiError(status, 'Bad Request: Invalid data provided', data);
        case 404:
          throw new ApiError(status, 'Not Found: Tag not found', data);
        case 500:
          throw new ApiError(status, 'Internal Server Error', data);
        default:
          throw new ApiError(status!, 'An unexpected error occurred', data);
      }
    } else {
      throw new ApiError(500, 'An unexpected error occurred', error);
    }
  }
};