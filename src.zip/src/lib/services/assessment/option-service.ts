import { AxiosError } from 'axios';
import axiosInstance from '../../api/axiosInstance';
import { ApiError } from '../../api/apiError';


interface CreateOptionProps {
  question_id: string;
  description: string;
  is_correct: boolean;
}

export const createOption = async (data: CreateOptionProps): Promise<void> => {
  try {
    const response = await axiosInstance.post('/v1/assessment/option', data);

    if (response.status === 200 || 201) {
      console.info('Option created successfully', response.data);
      return response.data;
    }
  } catch (error) {
    if (error instanceof AxiosError) {
      const { status, data } = error.response || {};
      switch (status) {
        case 400:
          throw new ApiError(status, 'Bad Request: Invalid data provided', data);
        case 500:
          throw new ApiError(status, 'Internal Server Error', data);
        default:
          throw new ApiError(status!, 'An unexpected error occurred', data);
      }
    } else {
      throw new ApiError(500, 'An unexpected error occurred', error);
    }
  }
};


interface UpdateOptionProps {
  id: string;
  description: string;
  is_correct: boolean;
}

export const updateOption = async (data: UpdateOptionProps): Promise<void> => {
  try {
    const response = await axiosInstance.patch('/v1/assessment/option', data);

    if (response.status === 200 || 201) {
      console.info('Option updated successfully', response.data);
      return response.data;
    }
  } catch (error) {
    if (error instanceof AxiosError) {
      const { status, data } = error.response || {};
      switch (status) {
        case 400:
          throw new ApiError(status, 'Bad Request: Invalid data provided', data);
        case 404:
          throw new ApiError(status, 'Not Found: Option not found', data);
        case 500:
          throw new ApiError(status, 'Internal Server Error', data);
        default:
          throw new ApiError(status!, 'An unexpected error occurred', data);
      }
    } else {
      throw new ApiError(500, 'An unexpected error occurred', error);
    }
  }
};


interface DeleteOptionProps {
  id: string;
}

export const deleteOption = async ({ id }: DeleteOptionProps): Promise<void> => {
  try {
    const response = await axiosInstance.delete('/v1/assessment/option', {
      data: { id },
    });

    if (response.status === 200 || 201) {
      console.info('Option deleted successfully', response.data);
      return;
    }
  } catch (error) {
    if (error instanceof AxiosError) {
      const { status, data } = error.response || {};
      switch (status) {
        case 400:
          throw new ApiError(status, 'Bad Request: Invalid data provided', data);
        case 404:
          throw new ApiError(status, 'Not Found: Option not found', data);
        case 500:
          throw new ApiError(status, 'Internal Server Error', data);
        default:
          throw new ApiError(status!, 'An unexpected error occurred', data);
      }
    } else {
      throw new ApiError(500, 'An unexpected error occurred', error);
    }
  }
};