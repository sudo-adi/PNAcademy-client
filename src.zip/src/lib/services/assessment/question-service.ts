import { ApiError, logError } from '@/lib/api/apiError';
import axiosInstance from '@/lib/api/axiosInstance';
import { AxiosError } from 'axios';


// Create Question
interface CreateQuestionProps {
  assessment_id: string;
  description: string;
  marks: number;
  section: number;
}

export const createQuestion = async (data: CreateQuestionProps): Promise<void> => {
  if (!data.assessment_id || typeof data.assessment_id !== 'string') {
    const error = new ApiError(400, 'Invalid request: Assessment ID is required and must be a string.');
    logError('Error in createQuestion', error);
    throw error;
  }

  try {
    const response = await axiosInstance.post('/v1/assessment/question', data);
    if (response.status === 200 || 201) {
      console.info('Question created successfully', response.data);
      return;
    } else {
      const warning = new Error('Unexpected status code');
      logError('Unexpected status code in createQuestion', warning, {
        status: response.status,
        data: response.data,
      });
      return;
    }
  } catch (error) {
    if (error instanceof AxiosError) {
      const { response } = error;
      if (response) {
        const { status, data } = response;
        switch (status) {
          case 400:
            throw new ApiError(status, 'Bad Request: Invalid data provided', data);
          case 500:
            throw new ApiError(status, 'Internal Server Error', data);
          default:
            throw new ApiError(status, 'An unexpected error occurred', data);
        }
      } else {
        throw new ApiError(500, 'Network error or unexpected error', error.message);
      }
    } else {
      throw new ApiError(500, 'An unexpected error occurred', error);
    }
  }
};


interface GetQuestionByIdProps {
  id: string;
}

export const getQuestionById = async ({ id }: GetQuestionByIdProps): Promise<any> => {
  if (!id || typeof id !== 'string') {
    const error = new ApiError(400, 'Invalid request: Question ID is required and must be a string.');
    logError('Error in getQuestionById', error);
    throw error;
  }

  try {
    const response = await axiosInstance.get('/v1/assessment/question', {
      params: { id },
    });

    if (response.status === 200 || 201) {
      console.info('Question fetched successfully', response.data);
      return response.data;
    } else {
      const warning = new Error('Unexpected status code');
      logError('Unexpected status code in getQuestionById', warning, {
        status: response.status,
        data: response.data,
      });
      return;
    }
  } catch (error) {
    if (error instanceof AxiosError) {
      const { response } = error;
      if (response) {
        const { status, data } = response;
        switch (status) {
          case 400:
            throw new ApiError(status, 'Bad Request: Invalid data provided', data);
          case 404:
            throw new ApiError(status, 'Not Found: Question not found', data);
          case 500:
            throw new ApiError(status, 'Internal Server Error', data);
          default:
            throw new ApiError(status, 'An unexpected error occurred', data);
        }
      } else {
        throw new ApiError(500, 'Network error or unexpected error', error.message);
      }
    } else {
      throw new ApiError(500, 'An unexpected error occurred', error);
    }
  }
};

// Update Question
interface UpdateQuestionProps {
  id: string;
  description: string;
  marks: number;
}

export const updateQuestion = async (data: UpdateQuestionProps): Promise<void> => {
  if (!data.id || typeof data.id !== 'string') {
    const error = new ApiError(400, 'Invalid request: Question ID is required and must be a string.');
    logError('Error in updateQuestion', error);
    throw error;
  }

  try {
    const response = await axiosInstance.patch('/v1/assessment/question', data);
    if (response.status === 200 || 201) {
      console.info('Question updated successfully', response.data);
      return;
    } else {
      const warning = new Error('Unexpected status code');
      logError('Unexpected status code in updateQuestion', warning, {
        status: response.status,
        data: response.data,
      });
      return;
    }
  } catch (error) {
    if (error instanceof AxiosError) {
      const { response } = error;
      if (response) {
        const { status, data } = response;
        switch (status) {
          case 400:
            throw new ApiError(status, 'Bad Request: Invalid data provided', data);
          case 404:
            throw new ApiError(status, 'Not Found: Question not found', data);
          case 500:
            throw new ApiError(status, 'Internal Server Error', data);
          default:
            throw new ApiError(status, 'An unexpected error occurred', data);
        }
      } else {
        throw new ApiError(500, 'Network error or unexpected error', error.message);
      }
    } else {
      throw new ApiError(500, 'An unexpected error occurred', error);
    }
  }
};


// Delete Question By Id
interface DeleteQuestionProps {
  id: string;
}

export const deleteQuestion = async ({ id }: DeleteQuestionProps): Promise<void> => {
  if (!id || typeof id !== 'string') {
    const error = new ApiError(400, 'Invalid request: Question ID is required and must be a string.');
    logError('Error in deleteQuestion', error);
    throw error;
  }

  try {
    const response = await axiosInstance.delete('/v1/assessment/question', {
      data: { id },
    });
    if (response.status === 200 || 201) {
      console.info('Question deleted successfully', response.data);
      return;
    } else {
      const warning = new Error('Unexpected status code');
      logError('Unexpected status code in deleteQuestion', warning, {
        status: response.status,
        data: response.data,
      });
      return;
    }
  } catch (error) {
    if (error instanceof AxiosError) {
      const { response } = error;
      if (response) {
        const { status, data } = response;
        switch (status) {
          case 400:
            throw new ApiError(status, 'Bad Request: Invalid data provided', data);
          case 404:
            throw new ApiError(status, 'Not Found: Question not found', data);
          case 500:
            throw new ApiError(status, 'Internal Server Error', data);
          default:
            throw new ApiError(status, 'An unexpected error occurred', data);
        }
      } else {
        throw new ApiError(500, 'Network error or unexpected error', error.message);
      }
    } else {
      throw new ApiError(500, 'An unexpected error occurred', error);
    }
  }
};