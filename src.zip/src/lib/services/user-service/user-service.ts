import axiosInstance from '../../api/axiosInstance';
import { getAccessToken } from '../../utils/tokenManager';

// Function to get user details
export const getUserDetails = async (): Promise<any> => {
  try {
    const token = getAccessToken();
    console.log('this is access token from usersercice file: ', token);
    if (!token) {
      throw new Error('No access token found');
    }
    const response = await axiosInstance.get('/v1/user/info');
    return response.data;
  } catch (error) {
    console.error('Failed to fetch user details:', error);
    throw error;
  }
};

type userType = {
  firstName: string,
  lastName: string,
  email: string,
  password: string,
  phone: string,
  roleId: string
}

// function to create users
export const createUser = async (user: userType): Promise<any> => {
  try {
    console.log('this is data from create user:', user);
    const response = await axiosInstance.post('/v1/user/register', {
      firstName: user.firstName,
      lastName: user.lastName,
      email: user.email,
      password: user.password,
      phone: user.phone,
      roleId: user.roleId,
    });
    console.log('this is response from create user: ', response.data);
    return response.data;
  } catch (error: any) {
    if (error.response.status === 409) {
      console.log('this is error from create user:', error.response.data);
      return error.response.status;
    }
    else {
      console.error('Failed to create user:', error);
    }

    throw error;
  }
};

// function to get all users
export const getAllUsers = async (page: number, pageSize: number): Promise<any> => {
  try {
    const response = await axiosInstance.get(`/v1/user/bulk?pageSize=${pageSize}&page=${page}`);
    console.log('this is response from get all users:', response.data);
    return response.data;
  } catch (error) {
    console.error('Failed to fetch all users:', error);
    throw error;
  }
};


// function to Get Sinlge User

