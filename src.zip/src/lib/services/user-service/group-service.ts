
import { ApiError } from '@/lib/api/apiError';
import axiosInstance from '@/lib/api/axiosInstance';
import { AxiosError } from 'axios';

interface CreateGroupProps {
  name: string;
}

export const createGroup = async (data: CreateGroupProps): Promise<void> => {
  try {
    const response = await axiosInstance.post('v1/create-group', data);

    if (response.status === 200 || 201) {
      console.info('Group created successfully', response.data);
      return response.data;
    }
  } catch (error) {
    if (error instanceof AxiosError) {
      const { status, data } = error.response || {};
      switch (status) {
        case 400:
          throw new ApiError(status, 'Bad Request: Invalid data provided', data);
        case 500:
          throw new ApiError(status, 'Internal Server Error', data);
        default:
          throw new ApiError(status!, 'An unexpected error occurred', data);
      }
    } else {
      throw new ApiError(500, 'An unexpected error occurred', error);
    }
  }
};

interface GetGroupsProps {
  id: string;
}

export const getGroups = async ({ id }: GetGroupsProps): Promise<void> => {
  try {
    const response = await axiosInstance.get(`/v1/groups?id=${id}`);
    if (response.status === 200 || 201) {
      console.info('Groups retrieved successfully', response.data);
      return response.data;
    }
  } catch (error) {
    if (error instanceof AxiosError) {
      const { status, data } = error.response || {};
      switch (status) {
        case 400:
          throw new ApiError(status, 'Bad Request: Invalid data provided', data);
        case 401:
          throw new ApiError(status, 'Unauthorized', data);
        case 404:
          throw new ApiError(status, 'Not Found: Groups not found', data);
        case 500:
          throw new ApiError(status, 'Internal Server Error', data);
        default:
          throw new ApiError(status!, 'An unexpected error occurred', data);
      }
    } else {
      throw new ApiError(500, 'An unexpected error occurred', error);
    }
  }
};

interface UpdateGroupProps {
  id: string;
  name: string;
}

export const updateGroup = async (data: UpdateGroupProps): Promise<void> => {
  try {
    const response = await axiosInstance.patch('/v1/group', data);

    if (response.status === 200) {
      console.info('Group updated successfully', response.data);
      return response.data;
    }
  } catch (error) {
    if (error instanceof AxiosError) {
      const { status, data } = error.response || {};
      switch (status) {
        case 400:
          throw new ApiError(status, 'Bad Request: Invalid data provided', data);
        case 500:
          throw new ApiError(status, 'Internal Server Error', data);
        default:
          throw new ApiError(status!, 'An unexpected error occurred', data);
      }
    } else {
      throw new ApiError(500, 'An unexpected error occurred', error);
    }
  }
};

interface DeleteGroupsProps {
  groupIds: string[];
}

export const deleteGroups = async ({ groupIds }: DeleteGroupsProps): Promise<void> => {
  try {
    const response = await axiosInstance.delete('/v1/groups', {
      data: { groupIds },
    });

    if (response.status === 200 || 201) {
      console.info('Groups deleted successfully', response.data);
      return;
    }
  } catch (error) {
    if (error instanceof AxiosError) {
      const { status, data } = error.response || {};
      switch (status) {
        case 400:
          throw new ApiError(status, 'Bad Request: Invalid data provided', data);
        case 404:
          throw new ApiError(status, 'Not Found: Group(s) not found', data);
        case 500:
          throw new ApiError(status, 'Internal Server Error', data);
        default:
          throw new ApiError(status!, 'An unexpected error occurred', data);
      }
    } else {
      throw new ApiError(500, 'An unexpected error occurred', error);
    }
  }
};