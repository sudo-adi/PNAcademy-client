import axiosInstance from "../../api/axiosInstance";
import { Permission } from "../../types/permissions";
import { getDecodedTokenData } from "../../utils/jwtUtils";

export const getRoleDetails = async (): Promise<any> => {
  try {
    const decodedTokenData = getDecodedTokenData();
    const { permissions } = decodedTokenData;
    console.log("Decoded token data permissions: ", permissions);
    return permissions;
  } catch (error) {
    console.error('Failed to fetch role details:', error);
    throw error;
  }
}

export const createRole = async (roleName: string, permissions: Permission) => {
  const {
    manageAssessments,
    manageUsers,
    manageRoles,
    manageNotifications,
    manageGroups,
    manageReports,
    attemptAssessments,
    viewReports,
    manageMyAccount,
    viewNotifications,
  } = permissions;

  try {
    const userPermissions = {
      canManageAssessment: manageAssessments || false,
      canManageUser: manageUsers || false,
      canManageRole: manageRoles || false,
      canManageNotification: manageNotifications || false,
      canManageLocalGroup: manageGroups || false,
      canManageReports: manageReports || false,
      canAttemptAssessment: attemptAssessments || false,
      canViewReport: viewReports || false,
      canManageMyAccount: manageMyAccount || false,
      canViewNotification: viewNotifications || false,
    };

    const requestBody = {
      name: roleName,
      permissions: userPermissions
    };
    console.log('Request body:', JSON.stringify(requestBody, null, 2));
    const response = await axiosInstance.post('/v1/user/role', requestBody);
    const { data } = response;
    console.log('Role created:', data);
    return data;
  } catch (error) {
    console.error('Failed to create role:', error);
    throw error;
  }
}

// get Roles Handeler
export const getRoles = async (page: number, pageSize: number) => {
  try {
    const response = await axiosInstance.get(`/v1/user/roles?pageSize=${pageSize}&page=${page}`);
    const { data } = response;
    console.log('Roles fetched:', data);
    console.log('Roles fetched:', data);
    return data;
  } catch (error) {
    console.error('Failed to fetch roles:', error);
    throw error;
  }
}

// delete role handeler
interface DeleteRequestBody {
  roleIds: {
    roleId: string;
  }[];
}

type DeleteResponse = {
  message: string;
  data: boolean;
}


// delete Role Handler
export const deleteRole = async (data: DeleteRequestBody): Promise<DeleteResponse> => {
  try {
    const response = await axiosInstance.delete<DeleteResponse>('/v1/user/role', {
      headers: {
        'Content-Type': 'application/json',
      },
      data: JSON.stringify(data),
    });
    return response.data;
  } catch (error) {
    console.error('Delete request failed:', error);
    throw error;
  }
};


