import React from 'react'

const Verification = () => {
  return (
    <main></main>
  )
}

export default Verification