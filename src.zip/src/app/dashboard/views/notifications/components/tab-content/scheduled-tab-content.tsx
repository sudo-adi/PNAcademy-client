import React from 'react'

const ScheduledTabContent = () => {
  return (
    <div className='w-full h-[calc(100vh-9rem)] flex items-center justify-center rounded-md border border-dashed'>
      Coming Soon
    </div>
  )
}

export default ScheduledTabContent