import React from 'react'

const AiCreate = () => {
  return (
    <div>AiCreate</div>
  )
}

export default AiCreate