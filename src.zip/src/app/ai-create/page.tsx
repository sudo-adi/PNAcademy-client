"use client"
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Separator } from '@/components/ui/separator'
import { Textarea } from '@/components/ui/textarea'
import { ArrowDown, ArrowLeft, ArrowRight, Loader, Loader2, RotateCw, SparklesIcon, Trash2 } from 'lucide-react'
import { useRouter } from 'next/navigation'
import { useEffect, useState } from 'react'
import { useAICreate } from './hooks/useAiCreate'
import useAiCreateStore from '@/lib/stores/ai-create/create-with-ai'
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu'
import { AiSection } from '@/lib/types/ai-assessment'
import { toast } from '@/components/ui/use-toast'
import { ToastAction } from '@/components/ui/toast'
import { number } from 'zod'

const AiCreate = () => {
  const router = useRouter();
  const [prompt, setPrompt] = useState<string>('');
  const [numberOfQuestions, setNumberOfQuestions] = useState<number>(0);
  const [difficultyLevel, setDifficultyLevel] = useState<string>('');
  const [generating, setGenerating] = useState<boolean>(false);
  const [sectionMarks, setSectionMarks] = useState<number>(0);
  const [disableGenerateButton, setDisableGenerateButton] = useState<boolean>(true);
  const { createQuestions, questionsResponse } = useAICreate();
  const [section, setSection] = useState<AiSection>();
  const { currentNumberOfQuestions, currentDifficultyLevel, currentMarksPerQuestion, currentSections, currentSectionIndex, currentQuestionIndex,
    setCurrentNumberOfQuestions, setCurrentDifficultyLevel, setCurrentMarksPerQuestion, setCurrentSectionIndex, setCurrentQuestionIndex,
  } = useAiCreateStore();
  const handleGenerateQuestions = async () => {
    setGenerating(true);
    try {
      console.log('Generating questions...');
      await createQuestions({
        topic: prompt,
        numberOfQuestions: numberOfQuestions,
        difficulty: difficultyLevel as "easy" | "medium" | "hard",
      });
    } catch (error) {
      console.log('Error generating questions:', error);
      toast({
        title: "Oops something went wrong",
        description: "An error occured while generating questions",
        action: (
          <ToastAction altText="try again" onClick={() => handleGenerateQuestions()}>Try Again</ToastAction>
        )
      });
    }
    setGenerating(false);
  }
  useEffect(() => {
    if (questionsResponse && questionsResponse.data.questions?.length > 0) {
      const retrivedNumberOfQuestions = questionsResponse!.data.questions.length;
      setCurrentNumberOfQuestions(questionsResponse!.data.questions.length);
      setCurrentSectionIndex(0);
      setCurrentQuestionIndex(0);
      const section = {
        prompt: prompt,
        sectionMarks: 0,
        questions: questionsResponse.data.questions
      }
      if (retrivedNumberOfQuestions != numberOfQuestions) {
        setNumberOfQuestions(retrivedNumberOfQuestions);
        toast({
          title: "Unable To generate all questions",
          description: `${retrivedNumberOfQuestions} questions generated`,
          action: (
            <ToastAction altText="ok">Ok</ToastAction>
          )
        });
      }
      else {
        toast({
          title: "Questions Generated",
          description: `${retrivedNumberOfQuestions} questions generated`,
          action: (
            <ToastAction altText="ok">Ok</ToastAction>
          )
        });
      }
      console.log('section:', questionsResponse?.data.questions);
    }

  }, [questionsResponse]);

  useEffect(() => {

    if (numberOfQuestions > 0 && difficultyLevel && prompt && sectionMarks >= 0) {
      setDisableGenerateButton(false);
    }
    else {
      setDisableGenerateButton(true);
    }
  }, [numberOfQuestions, sectionMarks, difficultyLevel, prompt]);

  return (
    <>
      <div className="flex flex-col items-center justify-start h-screen w-screen overflow-hidden">
        <div className="flex w-full h-[60px] border-b items-center justify-center px-5">
          <div className="flex items-center w-full h-full gap-2">
            <button
              disabled={generating}
              onClick={() => router.push('/dashboard')}
              className='text-[10px] border p-2 rounded-xl hover:bg-secondary'>
              <ArrowLeft className='h-4 w-4' />
            </button>
            <h1 className="text-white flex flex-row items-center gap-2">
              Create with AI
              <SparklesIcon className='h-4 w-4' />
            </h1>
          </div>
          <div className="flex w-full py-4">
            <Badge
              variant="outline">
              Section 1
            </Badge>
          </div>
          <Button size="sm" className='text-xs'>
            Create +
          </Button>
        </div>
        <div className="flex flex-col w-full py-4 px-10 gap-2">
          <div className="flex flex-col gap-2 w-full rounded-2xl h-full">
            <Label
              className='text-xs'>
              Prompt
            </Label>
            <Textarea
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Prompt here to generate Questions..."
              className="w-full  max-h-[5rem]"
            />
            <div className="flex flex-row gap-2 w-full">
              <div className="flex flex-col w-full gap-2">
                <Label className='text-[10px]'>
                  Number of Questions
                </Label>
                <Input
                  disabled={generating}
                  value={numberOfQuestions}
                  onChange={(e) => setNumberOfQuestions(parseInt(e.target.value))}
                  placeholder='Enter Number of Questions...'
                  type='number'
                  className='w-full'
                />
              </div>
              <div className="flex flex-col w-full gap-2">
                <Label className='text-[10px]'>
                  Choose Difficulty
                </Label>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button
                      disabled={generating}
                      variant="outline">
                      {difficultyLevel || '--  Select Difficulty  --'}
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent>
                    <DropdownMenuItem onSelect={() => setDifficultyLevel('easy')}>
                      Easy
                    </DropdownMenuItem>
                    <DropdownMenuItem onSelect={() => setDifficultyLevel('medium')}>
                      Medium
                    </DropdownMenuItem>
                    <DropdownMenuItem onSelect={() => setDifficultyLevel('hard')}>
                      Hard
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
              <div className="flex flex-col w-full gap-2">
                <Label className='text-[10px]'>
                  Marks Per Question
                </Label>
                <Input
                  disabled={generating}
                  placeholder='Enter Marks Each Question...'
                  type='number'
                  className='w-full'
                  onChange={(e) => setSectionMarks(parseInt(e.target.value))}
                />
              </div>
              <div className="flex flex-col w-full gap-2 items-baseline">
                <Label className='text-[10px]'>
                  Click to Generate
                </Label>
                <Button
                  disabled={generating || disableGenerateButton}
                  onClick={handleGenerateQuestions}
                  className='w-full'>
                  {generating ?
                    <>
                      Generating Questions
                      <Loader2 className="h-4 2-4 animate-spin" />
                    </>
                    : 'Generate Questions'}
                </Button>
              </div>
            </div>
          </div>
          <Separator />
          <div className="flex flex-col">
            {generating ? (
              <div className="flex flex-grow items-center justify-center overflow-scroll h-[calc(100vh-21rem)] w-full">
                <Loader2 className='h-10 w-10 animate-spin' />
              </div>
            ) : currentSections.length == 0 ? (
              <div className="flex flex-col border-2 border-dashed rounded-xl flex-grow items-center justify-center overflow-scroll h-[calc(100vh-21rem)] w-full">
                <div className="flex h-full w-full flex-col items-center justify-end">
                  Add a new sections by clicking down below the plus icon [+]
                </div>
                <div className="flex mt-1 border-[#e6e6e6] h-full w-[2px] border-l border-dashed ">
                </div>
                <ArrowDown className='h-8 w-8 mb-1' />
              </div>
            ) :
              (
                <div className="grid grid-cols-2 gap-2 overflow-scroll h-full w-full">
                  <div className="flex flex-col w-full gap-1">
                    <div className="flex flex-row justify-between items-center">
                      <Badge className='text-[10px] bg-primary' variant="outline">
                        Question 1
                      </Badge>
                      <button>
                        <Badge className='text-[10px] hover:bg-secondary' variant="outline">
                          Regenerate
                          <RotateCw className='h-3 w-3 ml-2' />
                        </Badge>
                      </button>
                    </div>
                    <Card className='flex flex-col h-full border-dotted p-4 text-[12px] gap-1'>
                      <Card className='flex w-full p-2 bg-secondary rounded-sm text-[10px]'>
                        Question: Lorem ipsum dolor sit amet consectetur adipisicing elit. At architecto voluptas natus! Suscipit nostrum esse unde vel aperiam, asperiores ullam?
                      </Card>
                      <div className='h-2'>
                      </div>
                      <div className="flex flex-col gap-2">
                        <div className="flex flex-col gap-1">
                          <div className="flex">
                            <Badge className='text-[10px] border-red-800' variant="outline">
                              option 1
                            </Badge>
                          </div>
                          <Card className='flex w-full p-2 rounded-sm border-dashed border-red-800 text-[10px]'>
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. At architecto voluptas natus! Suscipit nostrum esse unde vel aperiam, asperiores ullam?
                          </Card>
                        </div>
                        <div className="flex flex-col gap-1">
                          <div className="flex">
                            <Badge className='text-[10px] border-green-700 bg-green-700'>
                              option 1
                            </Badge>
                          </div>
                          <Card className='flex w-full p-2 rounded-sm border-dashed border-green-700 text-[10px]'>
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. At architecto voluptas natus! Suscipit nostrum esse unde vel aperiam, asperiores ullam?
                          </Card>
                        </div>
                        <div className="flex flex-col gap-1">
                          <div className="flex">
                            <Badge className='text-[10px] border-red-800' variant="outline">
                              option 1
                            </Badge>
                          </div>
                          <Card className='flex w-full p-2 rounded-sm border-dashed border-red-800 text-[10px]'>
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. At architecto voluptas natus! Suscipit nostrum esse unde vel aperiam, asperiores ullam?
                          </Card>
                        </div>
                        <div className="flex flex-col gap-1">
                          <div className="flex">
                            <Badge className='text-[10px] border-red-800' variant="outline">
                              option 1
                            </Badge>
                          </div>
                          <Card className='flex w-full p-2 rounded-sm border-dashed border-red-800 text-[10px]'>
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. At architecto voluptas natus! Suscipit nostrum esse unde vel aperiam, asperiores ullam?
                          </Card>
                        </div>
                      </div>
                    </Card>
                  </div>
                </div>
              )
            }
          </div>
          <div className="flex border border-dashed p-1 flex-row rounded-2xl items-center justify-between">
            <div className="flex flex-row gap-2">
              <Button
                disabled={currentSectionIndex === 0 || generating}
                variant={'outline'}>
                <ArrowLeft className='h-4 w-4' />
              </Button>
              {/* <Button
                disabled={currentSectionIndex === 0 || generating}
              >
                <ArrowRight className='h-4 w-4' />
              </Button> */}
            </div>
            <div className="flex flex-row gap-2">
              {/* {currentSections.map((index) => (
                <button
                  className={`flex items-center justify-center h-10 w-10 border rounded-sm hover:bg-secondary ${currentSectionIndex === index ? 'bg-secondary' : ''}`} key={index}>
                  {index}
                </button>
              ))} */}
              <button
                className='flex items-center justify-center h-10 w-10 border rounded-sm hover:bg-secondary'>
                +
              </button>
            </div>
            <Button
              disabled={generating}
              variant={'destructive'}
            >
              <Trash2 className='h-4 w-4' />
            </Button>
          </div>
        </div>
      </div >
    </>
  )
}

export default AiCreate