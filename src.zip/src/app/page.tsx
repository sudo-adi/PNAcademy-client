const Home = () => {
  return (
    <div className="flex items-center justify-center h-screen">
      Auth Redirection Page
    </div>
  )
}



export default Home