import React from 'react'

const Assessment = () => {
  return (
    <div className='flex items-center justify-center h-screen w-full'>
    </div>
  )
}

export default Assessment