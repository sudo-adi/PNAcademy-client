"use client"
import { Button } from '@/components/ui/button'
import { ApiError } from '@/lib/api/apiError'
import { logger } from '@/logger'
import { AxiosResponse } from 'axios'
import React from 'react'


const createAssessmentData = {
  name: "Assessment 01",
  description: "Hey There",
  is_active: true,
  start_at: "2024-08-09T19:07:24.753Z",
  end_at: "2024-08-09T19:07:24.753Z",
  duration: 4,
  created_by: "29d832ef-b488-4d87-8471-f9e1ce7e1841"
}

const idAss = {
  id: "fe9460d6-dd2a-49fe-a21e-e52f3e435556"
}

const idQs = {
  id: "70a90741-bb44-477e-8fef-1f5fc14b2d32"
}


const opsId = {
  id: "d79a1905-3d92-4289-a5aa-d2f126ad25b1"
}
const upDateAssessmentData = {
  id: "e8d34d9c-38d6-459c-ba70-bf8c61c3b878",
  name: "Assessment 02",
  description: "Updated Description",
  is_active: false,
  start_at: "2024-08-09T21:35:32.223Z",
  end_at: "2024-08-09T21:35:32.223Z",
  duration: 9
}
const createQuestionData = {
  assessment_id: "70a90741-bb44-477e-8fef-1f5fc14b2d32",
  description: "hello world",
  marks: 12,
  section: 40,

}

const upDateQuestionData = {
  id: "fe9460d6-dd2a-49fe-a21e-e52f3e435556",
  description: "updatd questioon",
  marks: 10
}


const createOptionData = {

  question_id: "53caddcc-83d5-45a5-9479-dce50d1826c1",
  description: "Answer 01",
  is_correct: true

}


const updateOptionData = {

  id: "bacb5d7d-9efe-4e37-b52f-59e2226fc019",
  description: "new option",
  is_correct: false

}




const Test = () => {
  return (
    <div className='flex items-center justify-center h-screen w-screen'>
      <Button onClick={() => {
        // updateAssessment(upDateAssessmentData);
        // createAssessment(createAssessmentData);
        // deleteAssessment(id)
        // getAssessment(idAss);
        // createQuestion(createQuestionData);
        // createOption(createOptionData);
        // deleteOption(opsId);
        // updateOption(updateOptionData);

        // try {
        //   getAssessment(deleteAssessmentData).then(res => console.log(res)).catch((err: ApiError) => console.log(err.status))

        // } catch (error: any) {
        //   console.log(error.details)
        // }

      }}>
        Load Data
      </Button>
    </div >
  )
}

export default Test